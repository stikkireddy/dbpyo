import builtins
import enum
import functools
import io
from pathlib import Path
from urllib.parse import urlparse

from pyspark.sql import SparkSession


class DatabricksWriter:

    def __init__(self, path, mode):
        file_name = str(Path(path).name)
        self._mode = mode
        self._folder_path = path.replace(file_name, "")
        self._file_dict = {}

    def add_file(self, file_name, blob):
        if file_name in self._file_dict:
            raise KeyError(f"file already exists: {file_name}")
        self._file_dict[file_name] = blob

    def write(self):
        if self._file_dict == {}:
            print("nothing to write")
            return None
        try:
            df = SparkSession.getActiveSession().createDataFrame([(k, v) for k, v in self._file_dict.items()],
                                                                 ["filename", "content"])
            SparkSession.getActiveSession().conf.set("spark.sql.sources.commitProtocolClass",
                                                     "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol")
            df.write.mode("append").format("blob").option("filemode", self._mode.value).save(self._folder_path)
            SparkSession.getActiveSession().conf.set("spark.sql.sources.commitProtocolClass",
                                                     "com.databricks.sql.transaction.directory.DirectoryAtomicCommitProtocol")
        except NameError:
            raise ValueError("Unable to find the spark variable.")


class FileMode(enum.Enum):
    WRITE_BINARY = 'wb'
    WRITE = 'w'
    APPEND_BINARY = 'ab'
    APPEND = 'a'
    READ_BINARY = 'rb'
    READ = 'r'


class DatabricksFile(io.IOBase):
    WRITE_MODES = [FileMode.WRITE, FileMode.WRITE_BINARY, FileMode.APPEND_BINARY, FileMode.APPEND]
    READ_MODES = [FileMode.READ, FileMode.READ_BINARY]

    def __init__(self, filename, mode):
        self._file_mode = mode
        self._filename = filename
        self._bytes_buffer = io.BytesIO()
        self._write_utils = DatabricksWriter(filename, mode)
        if mode in self.READ_MODES:
            self._spark_df = SparkSession.getActiveSession().read.format("binaryFile").load(self._filename)
            self._spark_df.cache()
        else:
            self._spark_df = None

    def seekable(self) -> bool:
        return False

    def read(self):
        if self._file_mode == FileMode.READ:
            return bytes(self._spark_df.collect()[0]["content"]).decode("UTF-8")
        elif self._file_mode == FileMode.READ_BINARY:
            return bytes(self._spark_df.collect()[0]["content"])
        else:
            raise ValueError(
                f"Invalid file mode: {self._file_mode} for reading, please use: {FileMode.READ_BINARY.value}"
                f" or {FileMode.READ.value}")

    def readlines(self, **kwargs):
        data = self.read()
        if isinstance(data, str):
            return data.split("\n")
        elif isinstance(data, bytes):
            return data.decode("UTF-8").split("\n")
        else:
            raise ValueError(f"Invalid file to support reading as string or split lines")

    def write(self, data):
        if self._file_mode == FileMode.WRITE_BINARY or self._file_mode == FileMode.APPEND_BINARY:
            self._bytes_buffer.write(data)
        elif self._file_mode == FileMode.WRITE or self._file_mode == FileMode.APPEND:
            self._bytes_buffer.write(data.encode("UTF-8"))
        else:
            raise ValueError(
                f"Invalid file mode: {self._file_mode} for writing, please use: {FileMode.WRITE_BINARY.value} "
                f"or {FileMode.WRITE.value}")

    def writelines(self, lines):
        if isinstance(lines, list):
            self.write("\n".join(lines))
        else:
            self.write(functools.reduce(lambda a, b: a + b, lines))

    def close(self):
        path = self._filename
        data = self._bytes_buffer.getvalue()
        if len(data) > 0 and self._file_mode in self.WRITE_MODES:
            self._write_utils.add_file(path, data)
            self._write_utils.write()
        self._bytes_buffer.close()


class DatabricksFileOpen:
    def __init__(self, filename, mode=FileMode.READ_BINARY.value):
        self._filename = filename
        self._mode = mode
        self._file = None

    def __enter__(self):
        self._file = DatabricksFile(self._filename, FileMode(self._mode))
        return self._file

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self._file.close()


# suppress any other fields
def open_lake(filename, mode=FileMode.READ.value, *args, **kwargs):
    return DatabricksFileOpen(filename, mode)


def monkey_patch(func):
    if hasattr(func, "wrapped") is True and func.wrapped is True:
        func = func._original

    @functools.wraps(func)
    def wrap_open(*args, **kwargs):
        path = args[0]
        p = urlparse(path)
        if p.scheme in ["abfss", "wasbs", "wasb", "s3", "s3a", "s3n", "adl", "adls", "gcs", "dbfs"]:
            return open_lake(*args, **kwargs)
        else:
            return func(*args, **kwargs)
    wrap_open.wrapped = True
    wrap_open._original = func
    return wrap_open


def monkey_patch_open():
    builtins.open = monkey_patch(open)
